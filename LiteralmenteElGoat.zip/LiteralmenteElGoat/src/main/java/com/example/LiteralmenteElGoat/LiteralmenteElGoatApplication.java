package com.example.LiteralmenteElGoat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiteralmenteElGoatApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiteralmenteElGoatApplication.class, args);
	}

}
